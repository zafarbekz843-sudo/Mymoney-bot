// routes/admin.js — admin panel uchun API
const express = require('express');
const router = express.Router();
const { db, getSetting, setSetting } = require('../db');
const { requireAdmin } = require('../middleware/adminAuth');
const { askClaude } = require('../lib/ai');

// ---- Kirish / chiqish ----
router.post('/login', (req, res) => {
  const { password } = req.body;
  if (password && password === process.env.ADMIN_PASSWORD) {
    req.session.isAdmin = true;
    return res.json({ ok: true });
  }
  res.status(401).json({ error: 'Parol noto\'g\'ri' });
});

router.post('/logout', (req, res) => {
  req.session = null;
  res.json({ ok: true });
});

router.get('/me', (req, res) => {
  res.json({ isAdmin: !!(req.session && req.session.isAdmin) });
});

// quyidagi barcha yo'llar login talab qiladi
router.use(requireAdmin);

// ---- Foydalanuvchilar ro'yxati ----
router.get('/users', (req, res) => {
  const rows = db.prepare(`
    SELECT u.id, u.username, u.first_name, u.created_at, u.last_active, u.blocked,
      COALESCE(SUM(CASE WHEN t.type = 'income' THEN t.amount ELSE 0 END), 0) AS income,
      COALESCE(SUM(CASE WHEN t.type = 'expense' THEN t.amount ELSE 0 END), 0) AS expense,
      COUNT(t.id) AS tx_count
    FROM users u
    LEFT JOIN transactions t ON t.user_id = u.id
    GROUP BY u.id
    ORDER BY u.last_active DESC
  `).all();
  res.json(rows);
});

// ---- Bitta foydalanuvchi haqida AI tahlil ----
router.get('/users/:id/ai-summary', async (req, res) => {
  const userId = req.params.id;
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!user) return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });

  const txs = db.prepare(`
    SELECT type, amount, category, comment, created_at
    FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 100
  `).all(userId);

  if (txs.length === 0) {
    return res.json({ summary: `${user.first_name || userId} hali hech qanday xarajat/daromad kiritmagan.` });
  }

  const dataText = txs.map(t =>
    `${t.created_at} | ${t.type === 'income' ? 'Daromad' : 'Xarajat'} | ${t.amount} so'm | ${t.category || '-'} | ${t.comment || ''}`
  ).join('\n');

  const summary = await askClaude({
    systemPrompt: "Siz moliyaviy tahlilchisiz. Sizga bitta foydalanuvchining xarajat/daromad tarixi beriladi. O'zbek tilida, 3-5 jumlada: umumiy moliyaviy holati, eng ko'p sarflagan kategoriyasi va bitta amaliy tavsiya bering. Ma'muriy panel uchun qisqa va lo'nda yozing.",
    userMessage: `Foydalanuvchi: ${user.first_name || userId}\n\nTarix:\n${dataText}`
  });

  res.json({ summary });
});

// ---- Xat tarqatish (broadcast) ----
router.post('/broadcast', async (req, res) => {
  const { message } = req.body;
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Xabar matni kerak' });
  }

  const bot = req.app.get('telegramBot');
  const users = db.prepare('SELECT id FROM users WHERE blocked = 0').all();

  let sent = 0, failed = 0;
  for (const u of users) {
    try {
      await bot.sendMessage(u.id, message);
      sent++;
    } catch (e) {
      failed++;
      // agar foydalanuvchi botni bloklagan bo'lsa, belgilab qo'yamiz
      if (e.response && e.response.statusCode === 403) {
        db.prepare('UPDATE users SET blocked = 1 WHERE id = ?').run(u.id);
      }
    }
    // Telegram rate-limit (~30 msg/sek) ga urilib qolmaslik uchun kichik pauza
    await new Promise(r => setTimeout(r, 40));
  }

  db.prepare('INSERT INTO broadcasts (message, sent_count, fail_count) VALUES (?, ?, ?)').run(message, sent, failed);
  res.json({ ok: true, sent, failed, total: users.length });
});

router.get('/broadcasts', (req, res) => {
  const rows = db.prepare('SELECT * FROM broadcasts ORDER BY sent_at DESC LIMIT 30').all();
  res.json(rows);
});

// ---- Bot / ilova sozlamalari ----
router.get('/settings', (req, res) => {
  const keys = ['welcome_message', 'ai_enabled', 'ai_system_prompt', 'default_monthly_limit'];
  const result = {};
  for (const k of keys) result[k] = getSetting(k);
  res.json(result);
});

router.post('/settings', (req, res) => {
  const allowedKeys = ['welcome_message', 'ai_enabled', 'ai_system_prompt', 'default_monthly_limit'];
  for (const key of allowedKeys) {
    if (req.body[key] !== undefined) setSetting(key, String(req.body[key]));
  }
  res.json({ ok: true });
});

// ---- Umumiy statistika (dashboard) ----
router.get('/stats', (req, res) => {
  const userCount = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  const txCount = db.prepare('SELECT COUNT(*) AS c FROM transactions').get().c;
  const totalExpense = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM transactions WHERE type='expense'`).get().s;
  const totalIncome = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM transactions WHERE type='income'`).get().s;
  const activeToday = db.prepare(`SELECT COUNT(*) AS c FROM users WHERE date(last_active) = date('now')`).get().c;
  res.json({ userCount, txCount, totalExpense, totalIncome, activeToday });
});

module.exports = router;
