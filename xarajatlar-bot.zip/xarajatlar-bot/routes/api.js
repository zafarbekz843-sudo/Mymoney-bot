// routes/api.js — mini-app uchun API (xarajat/daromad, jamg'arma, limit, statistika)
const express = require('express');
const router = express.Router();
const { db, getSetting } = require('../db');
const { checkTelegramAuth } = require('../middleware/telegramAuth');

router.use(checkTelegramAuth);

// har so'rovda foydalanuvchini bazaga yozib/yangilab qo'yamiz
router.use((req, res, next) => {
  const u = req.telegramUser;
  db.prepare(`
    INSERT INTO users (id, username, first_name, last_active)
    VALUES (?, ?, ?, datetime('now'))
    ON CONFLICT(id) DO UPDATE SET
      username = excluded.username,
      first_name = excluded.first_name,
      last_active = datetime('now')
  `).run(String(u.id), u.username || null, u.first_name || null);
  next();
});

// ---- Umumiy statistika (balans, bugungi xarajat, oylik limit) ----
router.get('/summary', (req, res) => {
  const userId = String(req.telegramUser.id);

  const totals = db.prepare(`
    SELECT
      COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) AS income,
      COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) AS expense
    FROM transactions WHERE user_id = ?
  `).get(userId);

  const today = db.prepare(`
    SELECT COALESCE(SUM(amount), 0) AS today_expense
    FROM transactions
    WHERE user_id = ? AND type = 'expense' AND date(created_at) = date('now')
  `).get(userId);

  const monthExpense = db.prepare(`
    SELECT COALESCE(SUM(amount), 0) AS month_expense
    FROM transactions
    WHERE user_id = ? AND type = 'expense' AND strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now')
  `).get(userId);

  const limit = db.prepare('SELECT amount, enabled FROM limits WHERE user_id = ?').get(userId);

  res.json({
    balance: totals.income - totals.expense,
    income: totals.income,
    expense: totals.expense,
    today_expense: today.today_expense,
    month_expense: monthExpense.month_expense,
    limit: limit ? { amount: limit.amount, enabled: !!limit.enabled } : null
  });
});

// ---- Tranzaksiyalar (xarajat/daromad) ----
router.get('/transactions', (req, res) => {
  const userId = String(req.telegramUser.id);
  const rows = db.prepare(`
    SELECT id, type, amount, category, comment, created_at
    FROM transactions WHERE user_id = ?
    ORDER BY created_at DESC LIMIT 200
  `).all(userId);
  res.json(rows);
});

router.post('/transactions', (req, res) => {
  const userId = String(req.telegramUser.id);
  const { type, amount, category, comment } = req.body;

  if (!['income', 'expense'].includes(type)) {
    return res.status(400).json({ error: 'type "income" yoki "expense" bo\'lishi kerak' });
  }
  const numAmount = Number(amount);
  if (!numAmount || numAmount <= 0) {
    return res.status(400).json({ error: 'Summa noto\'g\'ri' });
  }

  const result = db.prepare(`
    INSERT INTO transactions (user_id, type, amount, category, comment)
    VALUES (?, ?, ?, ?, ?)
  `).run(userId, type, numAmount, category || null, comment || null);

  res.json({ id: result.lastInsertRowid });
});

router.delete('/transactions/:id', (req, res) => {
  const userId = String(req.telegramUser.id);
  db.prepare('DELETE FROM transactions WHERE id = ? AND user_id = ?').run(req.params.id, userId);
  res.json({ ok: true });
});

// ---- Jamg'armalar ----
router.get('/savings', (req, res) => {
  const userId = String(req.telegramUser.id);
  const rows = db.prepare('SELECT * FROM savings WHERE user_id = ? ORDER BY created_at DESC').all(userId);
  res.json(rows);
});

router.post('/savings', (req, res) => {
  const userId = String(req.telegramUser.id);
  const { name, goal_amount } = req.body;
  if (!name || !goal_amount || Number(goal_amount) <= 0) {
    return res.status(400).json({ error: 'Nom va maqsad summasi kerak' });
  }
  const result = db.prepare(`
    INSERT INTO savings (user_id, name, goal_amount, current_amount)
    VALUES (?, ?, ?, 0)
  `).run(userId, name, Number(goal_amount));
  res.json({ id: result.lastInsertRowid });
});

router.post('/savings/:id/add', (req, res) => {
  const userId = String(req.telegramUser.id);
  const amount = Number(req.body.amount);
  if (!amount || amount <= 0) return res.status(400).json({ error: 'Summa noto\'g\'ri' });

  db.prepare(`
    UPDATE savings SET current_amount = current_amount + ?
    WHERE id = ? AND user_id = ?
  `).run(amount, req.params.id, userId);

  res.json({ ok: true });
});

// ---- Oylik limit ----
router.post('/limit', (req, res) => {
  const userId = String(req.telegramUser.id);
  const { amount, enabled } = req.body;
  db.prepare(`
    INSERT INTO limits (user_id, amount, enabled) VALUES (?, ?, ?)
    ON CONFLICT(user_id) DO UPDATE SET amount = excluded.amount, enabled = excluded.enabled
  `).run(userId, Number(amount) || 0, enabled ? 1 : 0);
  res.json({ ok: true });
});

// ---- Bot sozlamalaridan foydali qism (masalan xush kelibsiz matni) ----
router.get('/config', (req, res) => {
  res.json({
    default_monthly_limit: getSetting('default_monthly_limit') || null
  });
});

module.exports = router;
