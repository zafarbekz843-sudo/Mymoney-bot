// middleware/telegramAuth.js
// Telegram Mini App yuborgan initData'ni tekshiradi (soxta so'rovlarning oldini olish uchun)
const crypto = require('crypto');

function checkTelegramAuth(req, res, next) {
  const initData = req.headers['x-telegram-init-data'];
  if (!initData) {
    return res.status(401).json({ error: 'initData yo\'q' });
  }

  const botToken = process.env.BOT_TOKEN;
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  params.delete('hash');

  const pairs = [];
  for (const [key, value] of [...params.entries()].sort((a, b) => a[0].localeCompare(b[0]))) {
    pairs.push(`${key}=${value}`);
  }
  const dataCheckString = pairs.join('\n');

  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const computedHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');

  // Ishlab chiqish (dev) muhitida tekshiruvni yumshatish uchun ALLOW_INSECURE=1 qo'yish mumkin
  if (computedHash !== hash && process.env.ALLOW_INSECURE !== '1') {
    return res.status(401).json({ error: 'Noto\'g\'ri initData (hash mos kelmadi)' });
  }

  try {
    const userJson = params.get('user');
    req.telegramUser = userJson ? JSON.parse(userJson) : null;
  } catch (e) {
    req.telegramUser = null;
  }

  if (!req.telegramUser || !req.telegramUser.id) {
    return res.status(401).json({ error: 'Foydalanuvchi aniqlanmadi' });
  }

  next();
}

module.exports = { checkTelegramAuth };
