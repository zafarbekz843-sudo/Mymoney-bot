// server.js — asosiy kirish nuqtasi
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cookieSession = require('cookie-session');
const path = require('path');

const { createBot } = require('./bot');
const apiRoutes = require('./routes/api');
const adminRoutes = require('./routes/admin');

const app = express();
app.use(bodyParser.json());

app.use(cookieSession({
  name: 'admin_session',
  secret: process.env.SESSION_SECRET || 'iltimos-env-ga-sirli-kalit-qoying',
  maxAge: 24 * 60 * 60 * 1000 // 24 soat
}));

// mini-app va admin panel statik fayllari
app.use('/app', express.static(path.join(__dirname, 'public/miniapp')));
app.use('/admin', express.static(path.join(__dirname, 'public/admin')));

// API yo'llari
app.use('/api', apiRoutes);
app.use('/api/admin', adminRoutes);

app.get('/', (req, res) => {
  res.send('Bot ishlamoqda. Mini-app: /app, Admin panel: /admin');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server ${PORT}-portda ishga tushdi`);

  // botni ishga tushiramiz va admin broadcast uchun app'ga bog'laymiz
  const bot = createBot();
  app.set('telegramBot', bot);
  console.log('Telegram bot ishga tushdi (polling rejimida)');
});
