// bot.js — Telegram bot: /start, mini-app tugmasi va AI suhbat yordamchisi
const TelegramBot = require('node-telegram-bot-api');
const { db, getSetting } = require('./db');
const { askClaude } = require('./lib/ai');

function createBot() {
  const token = process.env.BOT_TOKEN;
  if (!token) {
    console.error('BOT_TOKEN topilmadi! .env faylni tekshiring.');
    process.exit(1);
  }

  const bot = new TelegramBot(token, { polling: true });

  bot.on('polling_error', (err) => console.error('Polling xatosi:', err.message));

  function upsertUser(msg) {
    const u = msg.from;
    db.prepare(`
      INSERT INTO users (id, username, first_name, last_active)
      VALUES (?, ?, ?, datetime('now'))
      ON CONFLICT(id) DO UPDATE SET
        username = excluded.username, first_name = excluded.first_name,
        last_active = datetime('now'), blocked = 0
    `).run(String(u.id), u.username || null, u.first_name || null);
  }

  bot.onText(/\/start/, (msg) => {
    upsertUser(msg);
    const welcome = getSetting('welcome_message') || "Xush kelibsiz!";
    const miniAppUrl = process.env.MINIAPP_URL;

    const options = miniAppUrl ? {
      reply_markup: {
        inline_keyboard: [[{ text: '📊 Ilovani ochish', web_app: { url: miniAppUrl } }]]
      }
    } : {};

    bot.sendMessage(msg.chat.id, welcome, options);
  });

  // /start va boshqa buyruqlardan tashqari har qanday matnli xabarga AI orqali javob berish
  bot.on('message', async (msg) => {
    if (!msg.text || msg.text.startsWith('/')) return;
    upsertUser(msg);

    const aiEnabled = getSetting('ai_enabled') === '1';
    if (!aiEnabled) return;

    const userId = String(msg.from.id);
    bot.sendChatAction(msg.chat.id, 'typing');

    const txs = db.prepare(`
      SELECT type, amount, category, comment, created_at
      FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50
    `).all(userId);

    const historyText = txs.length
      ? txs.map(t => `${t.created_at} | ${t.type === 'income' ? 'Daromad' : 'Xarajat'} | ${t.amount} so'm | ${t.category || '-'}${t.comment ? ' | ' + t.comment : ''}`).join('\n')
      : 'Hali hech qanday yozuv kiritilmagan.';

    const systemPrompt = getSetting('ai_system_prompt') ||
      "Siz foydalanuvchining shaxsiy moliyaviy yordamchisisiz. O'zbek tilida qisqa va aniq javob bering.";

    try {
      const reply = await askClaude({
        systemPrompt: `${systemPrompt}\n\nFoydalanuvchining so'nggi xarajat/daromad tarixi:\n${historyText}`,
        userMessage: msg.text
      });
      bot.sendMessage(msg.chat.id, reply);
    } catch (e) {
      console.error('AI javob xatosi:', e);
      bot.sendMessage(msg.chat.id, "Kechirasiz, hozir javob bera olmadim. Birozdan so'ng qayta urinib ko'ring.");
    }
  });

  return bot;
}

module.exports = { createBot };
