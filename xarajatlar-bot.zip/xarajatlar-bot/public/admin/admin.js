// admin.js — admin panel mantiqi

function fmt(n) { return Math.round(n || 0).toLocaleString('ru-RU') + " so'm"; }

async function api(path, options = {}) {
  const res = await fetch(`/api/admin${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Xatolik');
  }
  return res.json();
}

// ---------- Login ----------
async function checkSession() {
  const { isAdmin } = await api('/me');
  if (isAdmin) showDashboard(); else showLogin();
}
function showLogin() {
  document.getElementById('login-screen').style.display = 'flex';
  document.getElementById('dashboard').style.display = 'none';
}
function showDashboard() {
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('dashboard').style.display = 'flex';
  loadOverview();
}

document.getElementById('login-btn').addEventListener('click', async () => {
  const password = document.getElementById('login-password').value;
  try {
    await api('/login', { method: 'POST', body: JSON.stringify({ password }) });
    document.getElementById('login-error').textContent = '';
    showDashboard();
  } catch (e) {
    document.getElementById('login-error').textContent = e.message;
  }
});
document.getElementById('login-password').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') document.getElementById('login-btn').click();
});
document.getElementById('logout-btn').addEventListener('click', async () => {
  await api('/logout', { method: 'POST' });
  showLogin();
});

// ---------- Tab navigatsiyasi ----------
document.querySelectorAll('.side-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.side-btn').forEach(b => b.classList.toggle('active', b === btn));
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.getElementById(`tab-${btn.dataset.tab}`).classList.add('active');
    if (btn.dataset.tab === 'users') loadUsers();
    if (btn.dataset.tab === 'settings') loadSettings();
  });
});

// ---------- Umumiy ko'rsatkichlar ----------
async function loadOverview() {
  const stats = await api('/stats');
  document.getElementById('stat-users').textContent = stats.userCount;
  document.getElementById('stat-active').textContent = stats.activeToday;
  document.getElementById('stat-tx').textContent = stats.txCount;
  document.getElementById('stat-income').textContent = fmt(stats.totalIncome);
  document.getElementById('stat-expense').textContent = fmt(stats.totalExpense);

  const broadcasts = await api('/broadcasts');
  const wrap = document.getElementById('broadcast-history');
  wrap.innerHTML = broadcasts.length ? `
    <table><thead><tr><th>Sana</th><th>Xabar</th><th>Yuborildi</th><th>Xato</th></tr></thead>
    <tbody>${broadcasts.map(b => `<tr><td>${b.sent_at}</td><td>${b.message.slice(0, 60)}</td><td>${b.sent_count}</td><td>${b.fail_count}</td></tr>`).join('')}</tbody></table>
  ` : '<p class="muted" style="padding:16px">Hali xat tarqatilmagan.</p>';
}

// ---------- Foydalanuvchilar ----------
async function loadUsers() {
  const users = await api('/users');
  const tbody = document.getElementById('users-table-body');
  tbody.innerHTML = users.map(u => `
    <tr>
      <td>${u.first_name || '—'}</td>
      <td>${u.username ? '@' + u.username : '—'}</td>
      <td>${fmt(u.income)}</td>
      <td>${fmt(u.expense)}</td>
      <td>${u.tx_count}</td>
      <td>${u.last_active}</td>
      <td><button class="ai-btn" data-id="${u.id}" data-name="${u.first_name || u.id}">AI tahlil</button></td>
    </tr>
  `).join('');

  document.querySelectorAll('.ai-btn').forEach(btn => {
    btn.addEventListener('click', () => runAiSummary(btn.dataset.id, btn.dataset.name));
  });
}

async function runAiSummary(userId, name) {
  const panel = document.getElementById('ai-summary-panel');
  panel.style.display = 'block';
  document.getElementById('ai-panel-name').textContent = `AI tahlil — ${name}`;
  document.getElementById('ai-panel-text').textContent = 'Tahlil qilinmoqda...';
  panel.scrollIntoView({ behavior: 'smooth' });
  try {
    const { summary } = await api(`/users/${userId}/ai-summary`);
    document.getElementById('ai-panel-text').textContent = summary;
  } catch (e) {
    document.getElementById('ai-panel-text').textContent = 'Xatolik: ' + e.message;
  }
}
document.getElementById('ai-panel-close').addEventListener('click', () => {
  document.getElementById('ai-summary-panel').style.display = 'none';
});

// ---------- Xat tarqatish ----------
document.getElementById('broadcast-send-btn').addEventListener('click', async () => {
  const message = document.getElementById('broadcast-text').value;
  const resultEl = document.getElementById('broadcast-result');
  if (!message.trim()) { resultEl.textContent = 'Xabar matnini yozing.'; return; }
  resultEl.textContent = 'Yuborilmoqda...';
  try {
    const r = await api('/broadcast', { method: 'POST', body: JSON.stringify({ message }) });
    resultEl.textContent = `Yuborildi: ${r.sent} / ${r.total} (xato: ${r.failed})`;
    document.getElementById('broadcast-text').value = '';
  } catch (e) {
    resultEl.textContent = 'Xatolik: ' + e.message;
  }
});

// ---------- Sozlamalar ----------
async function loadSettings() {
  const s = await api('/settings');
  document.getElementById('setting-welcome').value = s.welcome_message || '';
  document.getElementById('setting-ai-enabled').checked = s.ai_enabled === '1';
  document.getElementById('setting-ai-prompt').value = s.ai_system_prompt || '';
  document.getElementById('setting-default-limit').value = s.default_monthly_limit || '';
}
document.getElementById('settings-save-btn').addEventListener('click', async () => {
  const resultEl = document.getElementById('settings-result');
  try {
    await api('/settings', {
      method: 'POST',
      body: JSON.stringify({
        welcome_message: document.getElementById('setting-welcome').value,
        ai_enabled: document.getElementById('setting-ai-enabled').checked ? '1' : '0',
        ai_system_prompt: document.getElementById('setting-ai-prompt').value,
        default_monthly_limit: document.getElementById('setting-default-limit').value
      })
    });
    resultEl.textContent = 'Saqlandi ✓';
  } catch (e) {
    resultEl.textContent = 'Xatolik: ' + e.message;
  }
});

checkSession();
