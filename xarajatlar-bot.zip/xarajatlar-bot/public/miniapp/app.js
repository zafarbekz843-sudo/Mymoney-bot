// app.js — mini-app mantiqi (backend API bilan ishlash)
const tg = window.Telegram ? window.Telegram.WebApp : null;
if (tg) { tg.ready(); tg.expand(); }

const INIT_DATA = tg ? tg.initData : '';

const CATEGORIES = {
  expense: [
    { id: 'uy', label: '🏠 Uy xarajatlari' },
    { id: 'kommunal', label: '💡 Kommunal' },
    { id: 'oziq_ovqat', label: '🛒 Oziq-ovqat' },
    { id: 'xaridlar', label: '🛍️ Xaridlar' },
    { id: 'transport', label: '🚗 Transport' },
    { id: 'boshqa', label: '📦 Boshqa' },
  ],
  income: [
    { id: 'oylik', label: '💼 Oylik maosh' },
    { id: 'biznes', label: '📈 Biznes' },
    { id: 'sovga', label: '🎁 Sovg\'a' },
    { id: 'boshqa', label: '📦 Boshqa' },
  ]
};

function fmt(n) {
  return Math.round(n).toLocaleString('ru-RU') + " so'm";
}

async function api(path, options = {}) {
  const res = await fetch(`/api${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'X-Telegram-Init-Data': INIT_DATA,
      ...(options.headers || {})
    }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Xatolik yuz berdi');
  }
  return res.json();
}

// ---------- Navigatsiya ----------
document.querySelectorAll('.nav-btn[data-view]').forEach(btn => {
  btn.addEventListener('click', () => switchView(btn.dataset.view));
});
function switchView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(`view-${name}`).classList.add('active');
  document.querySelectorAll('.nav-btn[data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === name));
  if (name === 'history') renderFullHistory();
  if (name === 'stats') renderStats();
}

// ---------- Modallar ----------
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('[data-close]').forEach(btn => {
  btn.addEventListener('click', () => closeModal(btn.dataset.close));
});

document.getElementById('add-tx-btn').addEventListener('click', () => {
  populateCategorySelect('expense');
  openModal('tx-modal-overlay');
});
document.getElementById('add-saving-btn').addEventListener('click', () => openModal('saving-modal-overlay'));

let currentTxType = 'expense';
document.querySelectorAll('.type-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    currentTxType = btn.dataset.type;
    document.querySelectorAll('.type-btn').forEach(b => b.classList.toggle('active', b === btn));
    populateCategorySelect(currentTxType);
  });
});
function populateCategorySelect(type) {
  const select = document.getElementById('tx-category');
  select.innerHTML = CATEGORIES[type].map(c => `<option value="${c.id}">${c.label}</option>`).join('');
}

// ---------- Tranzaksiya saqlash ----------
document.getElementById('tx-save-btn').addEventListener('click', async () => {
  const amount = document.getElementById('tx-amount').value;
  const category = document.getElementById('tx-category').value;
  const comment = document.getElementById('tx-comment').value;
  if (!amount || Number(amount) <= 0) {
    if (tg) tg.showAlert('Summani kiriting'); else alert('Summani kiriting');
    return;
  }
  try {
    await api('/transactions', { method: 'POST', body: JSON.stringify({ type: currentTxType, amount, category, comment }) });
    document.getElementById('tx-amount').value = '';
    document.getElementById('tx-comment').value = '';
    closeModal('tx-modal-overlay');
    await loadHome();
  } catch (e) {
    if (tg) tg.showAlert(e.message); else alert(e.message);
  }
});

// ---------- Jamg'arma saqlash ----------
document.getElementById('saving-save-btn').addEventListener('click', async () => {
  const name = document.getElementById('saving-name').value;
  const goal_amount = document.getElementById('saving-goal').value;
  if (!name || !goal_amount || Number(goal_amount) <= 0) {
    if (tg) tg.showAlert('Nom va summani to\'g\'ri kiriting'); else alert('Nom va summani to\'g\'ri kiriting');
    return;
  }
  try {
    await api('/savings', { method: 'POST', body: JSON.stringify({ name, goal_amount }) });
    document.getElementById('saving-name').value = '';
    document.getElementById('saving-goal').value = '';
    closeModal('saving-modal-overlay');
    await loadHome();
  } catch (e) {
    if (tg) tg.showAlert(e.message); else alert(e.message);
  }
});

// ---------- Oylik limit saqlash ----------
document.getElementById('save-limit-btn').addEventListener('click', async () => {
  const amount = document.getElementById('limit-input').value;
  const enabled = document.getElementById('limit-enabled').checked;
  try {
    await api('/limit', { method: 'POST', body: JSON.stringify({ amount, enabled }) });
    if (tg) tg.showAlert('Saqlandi'); else alert('Saqlandi');
    await loadHome();
  } catch (e) {
    if (tg) tg.showAlert(e.message); else alert(e.message);
  }
});

// ---------- Ma'lumotlarni yuklash / chizish ----------
function categoryIcon(catId) {
  const all = [...CATEGORIES.expense, ...CATEGORIES.income];
  const found = all.find(c => c.id === catId);
  return found ? found.label.split(' ')[0] : '📦';
}
function categoryLabel(catId) {
  const all = [...CATEGORIES.expense, ...CATEGORIES.income];
  const found = all.find(c => c.id === catId);
  return found ? found.label.slice(2).trim() : (catId || 'Boshqa');
}

function renderTxRow(t) {
  const date = new Date(t.created_at.replace(' ', 'T') + 'Z');
  const dateStr = date.toLocaleDateString('uz-UZ', { day: '2-digit', month: '2-digit' });
  return `
    <div class="tx-row">
      <div class="tx-left">
        <div class="tx-icon ${t.type}">${categoryIcon(t.category)}</div>
        <div>
          <div class="tx-cat">${categoryLabel(t.category)}</div>
          <div class="tx-date">${t.comment ? t.comment + ' · ' : ''}${dateStr}</div>
        </div>
      </div>
      <div class="tx-amount ${t.type}">${t.type === 'income' ? '+' : '-'}${fmt(t.amount)}</div>
    </div>`;
}

async function loadHome() {
  const [summary, txs, savings] = await Promise.all([
    api('/summary'), api('/transactions'), api('/savings')
  ]);

  document.getElementById('balance-amount').textContent = fmt(summary.balance);
  document.getElementById('income-amount').textContent = fmt(summary.income);
  document.getElementById('expense-amount').textContent = fmt(summary.expense);
  document.getElementById('today-expense').textContent = fmt(summary.today_expense);

  const limitEl = document.getElementById('limit-amount');
  if (summary.limit && summary.limit.enabled) {
    limitEl.textContent = fmt(summary.limit.amount);
    document.getElementById('limit-input').value = summary.limit.amount;
    document.getElementById('limit-enabled').checked = true;
  } else {
    limitEl.textContent = 'Belgilanmagan';
  }

  const savingsList = document.getElementById('savings-list');
  savingsList.innerHTML = savings.length ? savings.map(s => {
    const pct = Math.min(100, Math.round((s.current_amount / s.goal_amount) * 100));
    return `
      <div class="saving-card">
        <p>🎯 ${s.name}</p>
        <div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>
        <div class="amounts">${fmt(s.current_amount)} / ${fmt(s.goal_amount)}</div>
      </div>`;
  }).join('') : '<p class="empty-hint">Hali jamg\'arma yo\'q. "+ Yangi" tugmasini bosing.</p>';

  const recentList = document.getElementById('recent-list');
  const recent = txs.slice(0, 5);
  recentList.innerHTML = recent.length ? recent.map(renderTxRow).join('') : '<p class="empty-hint">Hali amallar yo\'q.</p>';
}

async function renderFullHistory() {
  const txs = await api('/transactions');
  const el = document.getElementById('full-tx-list');
  el.innerHTML = txs.length ? txs.map(renderTxRow).join('') : '<p class="empty-hint">Hali amallar yo\'q.</p>';
}

async function renderStats() {
  const [summary, txs] = await Promise.all([api('/summary'), api('/transactions')]);
  document.getElementById('month-expense').textContent = fmt(summary.month_expense);

  const byCategory = {};
  txs.filter(t => t.type === 'expense').forEach(t => {
    byCategory[t.category || 'boshqa'] = (byCategory[t.category || 'boshqa'] || 0) + t.amount;
  });
  const rows = Object.entries(byCategory).sort((a, b) => b[1] - a[1]);
  const el = document.getElementById('category-breakdown');
  el.innerHTML = rows.length
    ? rows.map(([cat, amt]) => `<div class="cat-row"><span>${categoryIcon(cat)} ${categoryLabel(cat)}</span><b>${fmt(amt)}</b></div>`).join('')
    : '<p class="empty-hint">Hali xarajat yo\'q.</p>';
}

// ---------- Ishga tushirish ----------
loadHome().catch(e => {
  console.error(e);
  document.getElementById('app').innerHTML = `<p style="padding:40px 20px;text-align:center;color:#888">
    Ilovani yuklab bo'lmadi. Iltimos, botni Telegram ichida oching.<br><small>${e.message}</small></p>`;
});
