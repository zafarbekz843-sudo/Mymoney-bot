// db.js — SQLite baza sozlamalari va sxemasi
const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'data.sqlite'));
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,               -- telegram user id
  username TEXT,
  first_name TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  last_active TEXT DEFAULT (datetime('now')),
  blocked INTEGER DEFAULT 0          -- foydalanuvchi botni bloklaganmi
);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  type TEXT NOT NULL,                -- 'income' | 'expense'
  amount REAL NOT NULL,
  category TEXT,
  comment TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS savings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  goal_amount REAL NOT NULL,
  current_amount REAL DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS limits (
  user_id TEXT PRIMARY KEY,
  amount REAL NOT NULL,
  enabled INTEGER DEFAULT 1,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS broadcasts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  message TEXT NOT NULL,
  sent_count INTEGER DEFAULT 0,
  fail_count INTEGER DEFAULT 0,
  sent_at TEXT DEFAULT (datetime('now'))
);
`);

// standart sozlamalar (agar mavjud bo'lmasa)
const defaults = {
  welcome_message: "👋 Xush kelibsiz!\n\nMen sizning shaxsiy xarajat va daromadlaringizni hisoblab boruvchi botman. Pastdagi tugma orqali ilovani oching va xarajatlaringizni kiritishni boshlang.",
  ai_enabled: "1",
  ai_system_prompt: "Siz foydalanuvchining shaxsiy moliyaviy yordamchisisiz. Sizga uning xarajat/daromad tarixi beriladi. Savollariga qisqa, aniq va do'stona ohangda, o'zbek tilida javob bering. Raqamlarni 'so'm' bilan ko'rsating.",
  default_monthly_limit: ""
};
const insertDefault = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
for (const [k, v] of Object.entries(defaults)) insertDefault.run(k, v);

function getSetting(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : null;
}
function setSetting(key, value) {
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(key, value);
}

module.exports = { db, getSetting, setSetting };
